# Datapack Totem Probability

Changes Mobloot to next list:

Blaze
Creeper
Drowned
Elder_Guardian
Enderman
Ghast
Guardian
Iron_golem
Piglin_brute
Piglin
Wither_Skeleton
Zombified_piglin
